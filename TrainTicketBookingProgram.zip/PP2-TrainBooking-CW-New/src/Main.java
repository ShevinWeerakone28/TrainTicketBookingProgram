import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.IOException;
import java.io.FileWriter;

public class Main extends Application {

    static final int SEATING_CAPACITY = 42;
    static int count = 0;
    static String letter;
    static String name;
    static ArrayList<Integer> seatBooked = new ArrayList<Integer>();
    static ArrayList<String> nameArr = new ArrayList<String>();
    static ArrayList<Integer> colour = new ArrayList<Integer>();
    static ArrayList<Integer> buttonArr = new ArrayList<Integer>();
    static ArrayList<Integer> pressed = new ArrayList<Integer>();
    static ArrayList<String> seatBook = new ArrayList<String>();
    static ArrayList<String> bookedSeat = new ArrayList<String>();
    static ArrayList<String> bookedBy = new ArrayList<String>();
    static ArrayList<String> names = new ArrayList<String>();


    static void vMethod(AnchorPane anchorPane) {

        Label lb = new Label(" Train Booking System ");

        lb.setStyle("-fx-background-color: #001347; -fx-text-fill: #b3ff00; -fx-border-color: black");
        lb.setFont(new Font(25));

        lb.setLayoutX(220);
        lb.setLayoutY(10);

        ArrayList<Button> seatsArray = new ArrayList<Button>();
        for ( int i = 0; i < SEATING_CAPACITY; i++) {
            int i2 = i + 1;
            seatsArray.add(new Button(String.valueOf(i2)));
            if ( count == 0 ) {
                pressed.add(0);
                seatBooked.add(i2);
            }
        }

        if ( count == 0 ) {
            for (int i = 0; i < seatsArray.size(); i++) {
                seatsArray.get(i).setStyle("-fx-background-color: green; -fx-text-fill: white; -fx-border-color: black");
                colour.add(1);
            }
            count += 1;
        }

        for ( int i=0; i<seatsArray.size(); i++ ) {
            seatsArray.get(i).setMinHeight(50);
            seatsArray.get(i).setMaxHeight(50);
            seatsArray.get(i).setMinWidth(50);
            seatsArray.get(i).setMaxWidth(50);
            if ( colour.get(i) == 1 ) {
                seatsArray.get(i).setStyle("-fx-background-color: green; -fx-text-fill: white; -fx-border-color: black");
            }else if ( colour.get(i) == 2 ) {
                seatsArray.get(i).setStyle("-fx-background-color: red; -fx-text-fill: white; -fx-border-color:black");
                seatsArray.get(i).setText("Taken");
            }
        }

        int initialX = 170;

        for ( int i = 0; i < 3; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(100);

            initialX += 50;
        }

        initialX = 420;

        for ( int i = 3; i < 5; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(100);

            initialX += 50;
        }

        initialX = 170;

        for ( int i = 5; i < 8; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(150);

            initialX += 50;
        }

        initialX = 420;

        for ( int i = 8; i < 10; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(150);

            initialX += 50;
        }

        initialX = 170;

        for ( int i = 10; i < 13; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(200);

            initialX += 50;
        }

        initialX = 420;

        for ( int i = 13; i < 15; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(200);

            initialX += 50;
        }

        initialX = 170;

        for ( int i = 15; i < 18; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(250);

            initialX += 50;
        }

        initialX = 420;

        for ( int i = 18; i < 20; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(250);

            initialX += 50;
        }

        initialX = 170;

        for ( int i = 20; i < 23; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(300);

            initialX += 50;
        }

        initialX = 420;

        for ( int i = 23; i < 25; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(300);

            initialX += 50;
        }

        initialX = 170;

        for ( int i = 25; i < 28; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(350);

            initialX += 50;
        }

        initialX = 420;

        for ( int i = 28; i < 30; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(350);

            initialX += 50;
        }

        initialX = 170;

        for ( int i = 30; i < 33; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(400);

            initialX += 50;
        }

        initialX = 420;

        for ( int i = 33; i < 35; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(400);

            initialX += 50;
        }

        initialX = 170;

        for ( int i = 35; i < 38; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(450);

            initialX += 50;
        }

        initialX = 420;

        for ( int i = 38; i < 40; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(450);

            initialX += 50;
        }

        initialX = 170;

        for ( int i = 40; i < 42; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(500);

            initialX += 50;
        }

        anchorPane.getChildren().add(lb);

        for (int i = 0; i < seatsArray.size(); i++) {
            anchorPane.getChildren().add(seatsArray.get(i));
        }
    }


    /*--------------------------------------------------------------------------------------------------------------*/


    static void aMethod(AnchorPane anchorPane) {

        Label lb = new Label(" Train Booking System ");
        TextField tf = new TextField("Enter your full name here");

        lb.setStyle("-fx-background-color: #001347; -fx-text-fill: #b3ff00; -fx-border-color: black");
        lb.setFont(new Font(25));

        tf.setStyle("-fx-background-color: #001347; -fx-text-fill: #b3ff00; -fx-border-color: black");
        tf.setFont(new Font(12));

        lb.setLayoutX(220);
        lb.setLayoutY(10);

        tf.setLayoutX(170);
        tf.setLayoutY(570);

        tf.setMinHeight(30);
        tf.setMaxHeight(30);
        tf.setMinWidth(250);
        tf.setMaxWidth(250);

        ArrayList<Button> seatsArray = new ArrayList<Button>();
        for ( int i = 0; i < SEATING_CAPACITY; i++) {
            int i2 = i + 1;
            seatsArray.add(new Button(String.valueOf(i2)));
            nameArr.add("empty");
            seatBook.add("empty");
            buttonArr.add(i2);
            if ( count == 0 ) {
                pressed.add(0);
                seatBooked.add(i2);
            }
        }

        if ( count == 0 ) {
            for (int i = 0; i < seatsArray.size(); i++) {
                seatsArray.get(i).setStyle("-fx-background-color: green; -fx-text-fill: white; -fx-border-color: black");
                colour.add(i, 1);
                count += 1;
            }
        }

        for ( int i=0; i<seatsArray.size(); i++ ) {
            seatsArray.get(i).setMinHeight(50);
            seatsArray.get(i).setMaxHeight(50);
            seatsArray.get(i).setMinWidth(50);
            seatsArray.get(i).setMaxWidth(50);
            if ( colour.get(i) == 1 ) {
                seatsArray.get(i).setStyle("-fx-background-color: green; -fx-text-fill: white; -fx-border-color: black");
            }else if ( colour.get(i) == 2 ) {
                seatsArray.get(i).setStyle("-fx-background-color: red; -fx-text-fill: white; -fx-border-color:black");
                seatsArray.get(i).setText("Taken");
                System.out.println("Seat No. " + buttonArr.get(i) + " was booked by " + nameArr.get(i));
            }
        }

        int initialX = 170;

        for ( int i = 0; i < 3; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(100);

            initialX += 50;
        }

        initialX = 420;

        for ( int i = 3; i < 5; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(100);

            initialX += 50;
        }

        initialX = 170;

        for ( int i = 5; i < 8; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(150);

            initialX += 50;
        }

        initialX = 420;

        for ( int i = 8; i < 10; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(150);

            initialX += 50;
        }

        initialX = 170;

        for ( int i = 10; i < 13; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(200);

            initialX += 50;
        }

        initialX = 420;

        for ( int i = 13; i < 15; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(200);

            initialX += 50;
        }

        initialX = 170;

        for ( int i = 15; i < 18; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(250);

            initialX += 50;
        }

        initialX = 420;

        for ( int i = 18; i < 20; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(250);

            initialX += 50;
        }

        initialX = 170;

        for ( int i = 20; i < 23; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(300);

            initialX += 50;
        }

        initialX = 420;

        for ( int i = 23; i < 25; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(300);

            initialX += 50;
        }

        initialX = 170;

        for ( int i = 25; i < 28; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(350);

            initialX += 50;
        }

        initialX = 420;

        for ( int i = 28; i < 30; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(350);

            initialX += 50;
        }

        initialX = 170;

        for ( int i = 30; i < 33; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(400);

            initialX += 50;
        }

        initialX = 420;

        for ( int i = 33; i < 35; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(400);

            initialX += 50;
        }

        initialX = 170;

        for ( int i = 35; i < 38; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(450);

            initialX += 50;
        }

        initialX = 420;

        for ( int i = 38; i < 40; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(450);

            initialX += 50;
        }

        initialX = 170;

        for ( int i = 40; i < 42; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(500);

            initialX += 50;
        }

        name = tf.getText();

        tf.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                for (int i = 0; i < seatsArray.size(); i++) {
                    int i2 = i;
                    int i3 = i + 1;
                    seatsArray.get(i).setOnAction(new EventHandler<ActionEvent>() {
                        @Override
                        public void handle(ActionEvent actionEvent) {
                            if ( pressed.get(i2) == 0  ) {
                                seatsArray.get(i2).setStyle("-fx-background-color: red; -fx-text-fill: white; -fx-border-color:black");
                                seatsArray.get(i2).setText("Taken");
                                System.out.println(tf.getText() + ", you booked Seat No. " + i3);
                                colour.set(i2, 2);
                                pressed.set(i2,1);
                                String nameField = tf.getText();
                                nameArr.set(i2, nameField);
                                names.add(nameField);
                                seatBook.set(i2,String.valueOf(i3));
                                bookedSeat.add(String.valueOf(i3));
                            }
                        }
                    });
                }
            }
        });

        for ( int i = 0; i < seatsArray.size(); i++ ) {
            seatsArray.get(i).setMinHeight(50);
            seatsArray.get(i).setMaxHeight(50);
            seatsArray.get(i).setMinWidth(50);
            seatsArray.get(i).setMaxWidth(50);
        }

        anchorPane.getChildren().add(lb);
        anchorPane.getChildren().add(tf);

        for (int i = 0; i < seatsArray.size(); i++) {
            anchorPane.getChildren().add(seatsArray.get(i));
        }
    }


    /*--------------------------------------------------------------------------------------------------------------*/


    static void eMethod(AnchorPane anchorPane) {

        Label lb = new Label(" Train Booking System ");

        lb.setStyle("-fx-background-color: #001347; -fx-text-fill: #b3ff00; -fx-border-color: black");
        lb.setFont(new Font(25));

        lb.setLayoutX(220);
        lb.setLayoutY(10);

        ArrayList<Button> seatsArray = new ArrayList<Button>();
        for ( int i = 0; i < SEATING_CAPACITY; i++) {
            int i2 = i + 1;
            seatsArray.add(new Button(String.valueOf(i2)));
        }

        for ( int i=0; i<seatsArray.size(); i++ ) {
            seatsArray.get(i).setMinHeight(50);
            seatsArray.get(i).setMaxHeight(50);
            seatsArray.get(i).setMinWidth(50);
            seatsArray.get(i).setMaxWidth(50);
        }

        int initialX = 170;

        for ( int i = 0; i < 3; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(100);

            initialX += 50;
        }

        initialX = 420;

        for ( int i = 3; i < 5; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(100);

            initialX += 50;
        }

        initialX = 170;

        for ( int i = 5; i < 8; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(150);

            initialX += 50;
        }

        initialX = 420;

        for ( int i = 8; i < 10; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(150);

            initialX += 50;
        }

        initialX = 170;

        for ( int i = 10; i < 13; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(200);

            initialX += 50;
        }

        initialX = 420;

        for ( int i = 13; i < 15; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(200);

            initialX += 50;
        }

        initialX = 170;

        for ( int i = 15; i < 18; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(250);

            initialX += 50;
        }

        initialX = 420;

        for ( int i = 18; i < 20; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(250);

            initialX += 50;
        }

        initialX = 170;

        for ( int i = 20; i < 23; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(300);

            initialX += 50;
        }

        initialX = 420;

        for ( int i = 23; i < 25; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(300);

            initialX += 50;
        }

        initialX = 170;

        for ( int i = 25; i < 28; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(350);

            initialX += 50;
        }

        initialX = 420;

        for ( int i = 28; i < 30; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(350);

            initialX += 50;
        }

        initialX = 170;

        for ( int i = 30; i < 33; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(400);

            initialX += 50;
        }

        initialX = 420;

        for ( int i = 33; i < 35; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(400);

            initialX += 50;
        }

        initialX = 170;

        for ( int i = 35; i < 38; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(450);

            initialX += 50;
        }

        initialX = 420;

        for ( int i = 38; i < 40; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(450);

            initialX += 50;
        }

        initialX = 170;

        for ( int i = 40; i < 42; i ++) {
            seatsArray.get(i).setLayoutX(initialX);
            seatsArray.get(i).setLayoutY(500);

            initialX += 50;
        }

        anchorPane.getChildren().add(lb);

        for (int i = 0; i < seatsArray.size(); i++) {
            if ( colour.get(i) == 1 ) {
                seatsArray.get(i).setStyle("-fx-background-color: green; -fx-text-fill: white; -fx-border-color: black");
            }else if ( colour.get(i) == 2 ) {
                seatsArray.get(i).setText("");
                seatsArray.get(i).setStyle("-fx-background-color: white; -fx-text-fill: black; -fx-border-color:black");
            }
            anchorPane.getChildren().add(seatsArray.get(i));
        }
    }


    /*--------------------------------------------------------------------------------------------------------------*/


    static void dMethod() {

        System.out.println("Please enter your full name: ");
        Scanner sc1 = new Scanner(System.in);
        name = sc1.nextLine();

        ArrayList<Integer> confirm = new ArrayList<Integer>();

        for (int i = 0; i < nameArr.size(); i++) {
            int i2 = i;
            if (name.equals(nameArr.get(i2))) {
                System.out.println("Are you sure you want to delete yourself from Seat No. " + seatBooked.get(i2) + "\nPress 1 to confirm deletion:\nPress 2 to keep the seat booked : ");
                Scanner sc2 = new Scanner(System.in);
                int confirmation = sc2.nextInt();
                confirm.add(confirmation);
                if (confirmation == 1) {
                    nameArr.set(i2, "empty");
                    seatBook.set(i2, "empty");
                    colour.set(i2, 1);
                    pressed.set(i2, 0);
                }
            }
        }

        names.clear();
        bookedSeat.clear();

        for (int count = 0; count < nameArr.size(); count++) {
            if (nameArr.get(count) != "empty") {
                names.add(nameArr.get(count));
                bookedSeat.add(seatBook.get(count));
            }
        }

        for ( int i = 0; i < 42; i ++ ) {
            int i3 = i + 1;
            System.out.println(i3 + " - " + nameArr.get(i) + " - " + seatBook.get(i));
        }
        for ( int i = 0; i < names.size(); i ++ ) {
            int i3 = i + 1;
            System.out.println(i3 + " - " + names.get(i) + " - " + bookedSeat.get(i));
        }
    }


    /*--------------------------------------------------------------------------------------------------------------*/


    static void fMethod() {

        System.out.println("Please enter your full name: ");
        Scanner sc1 = new Scanner(System.in);
        name = sc1.nextLine();

        System.out.println(name + ", the seats currently booked under your name are: ");

        for ( int i = 0; i < nameArr.size(); i ++ ) {
            int i2 = i;
            if (name.equals(nameArr.get(i2))) {
                System.out.println("Seat No. " + seatBooked.get(i2));
            }
        }

    }


    /*--------------------------------------------------------------------------------------------------------------*/


    static void oMethod() {

        for ( int i = 0; i < names.size(); i ++ ) {
            for ( int i2 = i + 1; i2 < names.size(); i2 ++ ) {

                if (names.get(i).compareTo(names.get(i2)) > 0 ) {

                    String temp = names.get(i);
                    names.set(i, names.get(i2));
                    names.set(i2, temp);

                    if ( names.get(i).equals(names.get(i2)) ) {
                        if ( Integer.parseInt(bookedSeat.get(i)) > Integer.parseInt(bookedSeat.get(i2)) ) {
                            String temp3 = bookedSeat.get(i);
                            bookedSeat.set(i, bookedSeat.get(i2));
                            bookedSeat.set(i2, temp3);
                        }
                    }else{
                        String temp2 = bookedSeat.get(i);
                        bookedSeat.set(i, bookedSeat.get(i2));
                        bookedSeat.set(i2, temp2);
                    }
                }
            }
        }

        System.out.println("Sorted the array : " + names);
        for ( int i3 = 0; i3 < names.size(); i3 ++ ) {
            System.out.println(names.get(i3) + " - " + bookedSeat.get(i3));
        }
    }


    /*--------------------------------------------------------------------------------------------------------------*/


    static void sMethod() {

        try {
            File myObject = new File("C:\\TrainSeatBookingProgram\\DenuwaraMenikeTrainToBadulla.txt");
            if ( myObject.createNewFile() ) {
                System.out.println(myObject.getName() + " was created successfully.");
            }else {
                System.out.println("File already exists.");
            }

            FileWriter writer = new FileWriter("C:\\TrainSeatBookingProgram\\DenuwaraMenikeTrainToBadulla.txt");
            writer.write(String.valueOf(bookedBy));
            writer.close();

        }catch ( IOException e ) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }


    /*--------------------------------------------------------------------------------------------------------------*/


    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {

        AnchorPane anchorPane = new AnchorPane();
        System.out.println("Welcome to the Denuwara Menike train to Badulla seat booking program\n");

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter 'A' to add yourself to a seat,");
        System.out.println("Enter 'V' to view all seats,");
        System.out.println("Enter 'E' to display empty seats,");
        System.out.println("Enter 'S' to store program data into the file,");
        System.out.println("Enter 'L' to load program data from the file,");
        System.out.print("Enter 'O' to view seats ordered alphabetically by name : ");
        letter = sc.nextLine().toUpperCase();

        if (letter.equals("Q")) {
            System.exit(1);
        }else if (letter.equals("V")) {
            vMethod(anchorPane);
        }else if ( letter.equals("A") ) {
            aMethod(anchorPane);
        }else if ( letter.equals("E") ) {
            vMethod(anchorPane);
        }

        stage.setScene(new Scene(anchorPane, 700, 700));
        stage.show();

        Button menu = new Button("Menu");
        menu.setStyle("-fx-background-color: #001347; -fx-text-fill: #b3ff00; -fx-border-color: black");
        anchorPane.getChildren().add(menu);

        menu.setLayoutX(470);
        menu.setLayoutY(570);

        menu.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                stage.close();
                AnchorPane anchorPane = new AnchorPane();
                System.out.println("\n\nWelcome to the Denuwara Menike train to Badulla seat booking program\n");

                Scanner sc = new Scanner(System.in);
                System.out.println("Enter 'A' to add yourself to a seat,");
                System.out.println("Enter 'V' to view all seats,");
                System.out.println("Enter 'E' to display empty seats,");
                System.out.println("Enter 'D' to delete yourself from a seat,");
                System.out.println("Enter 'F' to find a seat under your name,");
                System.out.println("Enter 'S' to store program data into the file,");
                System.out.println("Enter 'L' to load program data from the file,");
                System.out.print("Enter 'O' to view seats ordered alphabetically by name : ");
                letter = sc.nextLine().toUpperCase();

                if (letter.equals("Q")) {
                    System.exit(1);
                }else if (letter.equals("V")) {
                    vMethod(anchorPane);
                    stage.setScene(new Scene(anchorPane, 700, 700));
                    stage.show();
                    anchorPane.getChildren().add(menu);
                }else if ( letter.equals("A") ) {
                    aMethod(anchorPane);
                    stage.setScene(new Scene(anchorPane, 700, 700));
                    stage.show();
                    anchorPane.getChildren().add(menu);
                }else if ( letter.equals("E") ) {
                    eMethod(anchorPane);
                    stage.setScene(new Scene(anchorPane, 700, 700));
                    stage.show();
                    anchorPane.getChildren().add(menu);
                }else if ( letter.equals("D") ) {
                    dMethod();
                    menu.fire();
                }else if ( letter.equals("O") ) {
                    oMethod();
                    menu.fire();
                }else if ( letter.equals("F") ) {
                    fMethod();
                    menu.fire();
                }else if ( letter.equals("S") ) {
                    sMethod();
                    menu.fire();
                }else{
                    stage.setScene(new Scene(anchorPane, 700, 700));
                    stage.show();
                    anchorPane.getChildren().add(menu);
                }
            }
        });
    }
}